

package application;

import java.io.*;
import java.net.*;
import java.util.Date;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;


public class Main extends Application {
	public static String isPrime(int num) {
	       if(num<2) {
	           return "This Number is not Prime";
	       }
	       int i=2;
	       while(i<num) {
	           if(num%i==0) {
	               return "This Number is not Prime";
	           }
	           i++;
	       }
	       return "This is a Prime Number";      
	   }
	
	

  @Override // Override the start method in the Application class
  
  
  
  public void start(Stage primaryStage) {
    // Text area for displaying contents
    TextArea ta = new TextArea();

    // Create a scene and place it in the stage
    Scene scene = new Scene(new ScrollPane(ta), 450, 200);
    primaryStage.setTitle("Server"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
    
    new Thread( () -> {
      try {
        // Create a server socket
        ServerSocket serverSocket = new ServerSocket(8000);
        Platform.runLater(() ->
          ta.appendText("Server started at " + new Date() + '\n'));
  
        // Listen for a connection request
        Socket socket = serverSocket.accept();
  
        // Create data input and output streams
        DataInputStream inputFromClient = new DataInputStream(
          socket.getInputStream());
        DataOutputStream outputToClient = new DataOutputStream(
          socket.getOutputStream());
        
        
        
        while (true) {
        	
        	
        	
        	int num = (int)inputFromClient.readInt();
            // CALLING FUNCTION AND
            // WRITING RETURN VALUE TO CLIENT
        	outputToClient.writeUTF(isPrime(num));
        	outputToClient.flush();
        	Platform.runLater(() -> {
                ta.appendText("number received from client: " 
                  + num + '\n');
                ta.appendText("Prime or Not is: " + isPrime(num) + '\n');
        	});
        }
        
        
    }
    
    

      catch(IOException ex) {
        ex.printStackTrace();
      }
    }).start();
  }

 
public static void main(String[] args) {    launch(args);  
}
}

